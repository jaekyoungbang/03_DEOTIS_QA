from fastapi import APIRouter, HTTPException
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from services.vector_store import VectorStoreService

router = APIRouter()
vector_store_service = VectorStoreService()

@router.post("/reset-database")
async def reset_database():
    try:
        collection = vector_store_service.client.get_collection("documents")
        collection.delete()
        
        return {"message": "데이터베이스가 초기화되었습니다."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"데이터베이스 초기화 중 오류가 발생했습니다: {str(e)}")

@router.get("/stats")
async def get_database_stats():
    try:
        collection = vector_store_service.client.get_collection("documents")
        count = collection.count()
        
        return {
            "total_documents": count,
            "collection_name": "documents"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"통계 조회 중 오류가 발생했습니다: {str(e)}")