from fastapi import APIRouter, HTTPException
from typing import List

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from models.schemas import ChatMessage, ChatResponse
from services.rag_service import RAGService

router = APIRouter()
rag_service = RAGService()

@router.post("/chat", response_model=ChatResponse)
async def chat(message: ChatMessage):
    try:
        if not message.message.strip():
            raise HTTPException(status_code=400, detail="메시지를 입력해주세요.")
        
        result = rag_service.get_response(
            query=message.message,
            chat_history=message.history
        )
        
        return ChatResponse(
            response=result["response"],
            sources=[source["source"] for source in result["sources"]]
        )
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"채팅 처리 중 오류가 발생했습니다: {str(e)}")

@router.get("/health")
async def chat_health():
    return {"status": "chat service is healthy"}