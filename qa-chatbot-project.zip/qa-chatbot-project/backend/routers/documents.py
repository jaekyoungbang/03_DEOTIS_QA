from fastapi import APIRouter, UploadFile, File, HTTPException
from typing import List
import os
import uuid
import shutil
from datetime import datetime

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from models.schemas import DocumentProcessResponse, DocumentInfo
from utils.document_processor import DocumentProcessor
from services.vector_store import VectorStoreService
from config.settings import settings

router = APIRouter()
document_processor = DocumentProcessor()
vector_store_service = VectorStoreService()

UPLOAD_DIRECTORY = "./uploads"
os.makedirs(UPLOAD_DIRECTORY, exist_ok=True)

@router.post("/upload", response_model=DocumentProcessResponse)
async def upload_document(file: UploadFile = File(...)):
    try:
        file_extension = os.path.splitext(file.filename)[1]
        
        if file_extension not in settings.allowed_file_types:
            raise HTTPException(
                status_code=400, 
                detail=f"지원하지 않는 파일 형식입니다. 허용된 형식: {', '.join(settings.allowed_file_types)}"
            )
        
        document_id = str(uuid.uuid4())
        file_path = os.path.join(UPLOAD_DIRECTORY, f"{document_id}_{file.filename}")
        
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        if not document_processor.validate_file(file_path, file_extension):
            os.remove(file_path)
            raise HTTPException(status_code=400, detail="파일 크기가 너무 크거나 유효하지 않습니다.")
        
        documents = document_processor.process_document(file_path, file_extension)
        
        vector_store_service.add_documents(documents, document_id)
        
        return DocumentProcessResponse(
            success=True,
            message="문서가 성공적으로 업로드되고 처리되었습니다.",
            document_id=document_id
        )
    
    except Exception as e:
        if 'file_path' in locals() and os.path.exists(file_path):
            os.remove(file_path)
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/list", response_model=List[DocumentInfo])
async def list_documents():
    try:
        documents = []
        for filename in os.listdir(UPLOAD_DIRECTORY):
            file_path = os.path.join(UPLOAD_DIRECTORY, filename)
            if os.path.isfile(file_path):
                stat = os.stat(file_path)
                document_id = filename.split('_')[0]
                original_filename = '_'.join(filename.split('_')[1:])
                
                documents.append(DocumentInfo(
                    id=document_id,
                    filename=original_filename,
                    upload_date=datetime.fromtimestamp(stat.st_ctime),
                    file_size=stat.st_size,
                    status="processed"
                ))
        
        return documents
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/{document_id}")
async def delete_document(document_id: str):
    try:
        files_to_delete = [f for f in os.listdir(UPLOAD_DIRECTORY) if f.startswith(document_id)]
        
        if not files_to_delete:
            raise HTTPException(status_code=404, detail="문서를 찾을 수 없습니다.")
        
        for filename in files_to_delete:
            file_path = os.path.join(UPLOAD_DIRECTORY, filename)
            os.remove(file_path)
        
        vector_store_service.delete_document(document_id)
        
        return {"message": "문서가 성공적으로 삭제되었습니다."}
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))