from typing import List, Optional
import chromadb
from chromadb.config import Settings as ChromaSettings
from langchain_community.embeddings import OllamaEmbeddings
from langchain_community.vectorstores import Chroma
from langchain.schema import Document

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from config.settings import settings

class VectorStoreService:
    def __init__(self):
        self.embeddings = OllamaEmbeddings(
            model=settings.embedding_model,
            base_url=settings.ollama_base_url
        )
        
        self.client = chromadb.PersistentClient(
            path=settings.vector_db_path,
            settings=ChromaSettings(anonymized_telemetry=False)
        )
        
        self._handle_dimension_mismatch()
        
        self.vectorstore = Chroma(
            client=self.client,
            collection_name="documents",
            embedding_function=self.embeddings
        )
    
    def _handle_dimension_mismatch(self):
        try:
            collection = self.client.get_collection("documents")
            try:
                test_embedding = self.embeddings.embed_query("test")
                collection.add(
                    embeddings=[test_embedding],
                    documents=["test"],
                    ids=["test_dimension_check"]
                )
                collection.delete(ids=["test_dimension_check"])
            except Exception as e:
                if "dimension" in str(e).lower():
                    print(f"Embedding dimension mismatch detected. Recreating collection...")
                    self.client.delete_collection("documents")
                else:
                    raise e
        except Exception:
            pass
    
    def add_documents(self, documents: List[Document], document_id: str):
        for i, doc in enumerate(documents):
            doc.metadata["document_id"] = document_id
            doc.metadata["chunk_id"] = f"{document_id}_{i}"
        
        self.vectorstore.add_documents(documents)
    
    def delete_document(self, document_id: str):
        collection = self.client.get_collection("documents")
        
        results = collection.get(where={"document_id": document_id})
        
        if results["ids"]:
            collection.delete(ids=results["ids"])
    
    def similarity_search(self, query: str, k: int = 4) -> List[Document]:
        return self.vectorstore.similarity_search(query, k=k)
    
    def similarity_search_with_score(self, query: str, k: int = 4):
        return self.vectorstore.similarity_search_with_score(query, k=k)
    
    def get_retriever(self, search_kwargs: Optional[dict] = None):
        if search_kwargs is None:
            search_kwargs = {"k": 4}
        
        return self.vectorstore.as_retriever(search_kwargs=search_kwargs)