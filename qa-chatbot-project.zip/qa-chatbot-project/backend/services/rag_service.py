from typing import List, Dict, Any
from langchain_community.llms import Ollama
from langchain.schema import HumanMessage, SystemMessage, AIMessage
from langchain.prompts import ChatPromptTemplate
from langchain.schema.runnable import RunnablePassthrough
from langchain.schema.output_parser import StrOutputParser

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from config.settings import settings
from services.vector_store import VectorStoreService

class RAGService:
    def __init__(self):
        self.llm = Ollama(
            model=settings.llm_model,
            base_url=settings.ollama_base_url,
            temperature=0.1
        )
        
        self.vector_store_service = VectorStoreService()
        self.retriever = self.vector_store_service.get_retriever({"k": 4})
        
        self.system_prompt = """
        당신은 문서 기반 질문 답변 시스템입니다. 
        주어진 문서 내용을 바탕으로 사용자의 질문에 정확하고 도움이 되는 답변을 제공하세요.
        
        답변 시 다음 규칙을 따르세요:
        1. 제공된 컨텍스트에서 직접적으로 관련된 정보를 찾아 답변하세요.
        2. 문서에서 찾을 수 없는 정보는 "문서에서 관련 정보를 찾을 수 없습니다"라고 명시하세요.
        3. 답변은 명확하고 간결하게 작성하세요.
        4. 한국어로 답변하세요.
        5. 컨텍스트 내용이 표 형식이거나 구조화된 데이터인 경우, 답변도 markdown 표 형식으로 정리하여 제공하세요.
        """
    
    def format_documents(self, documents: List[Any]) -> str:
        formatted_docs = []
        for i, doc in enumerate(documents, 1):
            content = doc.page_content if hasattr(doc, 'page_content') else str(doc)
            source = doc.metadata.get('source', 'Unknown') if hasattr(doc, 'metadata') else 'Unknown'
            
            # 표 형식 여부 체크
            is_table_format = self._is_table_format(content)
            table_note = " (표 형식 데이터)" if is_table_format else ""
            
            formatted_docs.append(f"문서 {i} (출처: {source}){table_note}:\n{content}\n")
        return "\n".join(formatted_docs)
    
    def _is_table_format(self, content: str) -> bool:
        """컨텍스트가 표 형식인지 확인"""
        # 마크다운 표 형식 체크
        if '|' in content and ('---' in content or '---|' in content):
            return True
        # CSV 형식 체크
        if ',' in content and content.count('\n') > 1:
            lines = content.split('\n')
            if len(lines) > 1:
                first_row_cols = len(lines[0].split(','))
                return all(len(line.split(',')) == first_row_cols for line in lines[1:3] if line.strip())
        # 탭 구분 형식 체크
        if '\t' in content and content.count('\n') > 1:
            return True
        return False
    
    def create_rag_chain(self):
        prompt = ChatPromptTemplate.from_messages([
            ("system", self.system_prompt),
            ("human", """참고 문서:
{context}

질문: {question}""")
        ])
        
        rag_chain = (
            {"context": self.retriever | self.format_documents, "question": RunnablePassthrough()}
            | prompt
            | self.llm
            | StrOutputParser()
        )
        
        return rag_chain
    
    def get_response(self, query: str, chat_history: List[Dict] = None) -> Dict[str, Any]:
        try:
            relevant_docs = self.vector_store_service.similarity_search_with_score(query, k=4)
            
            if not relevant_docs:
                return {
                    "response": "관련 문서를 찾을 수 없습니다. 문서를 업로드하거나 다른 질문을 시도해보세요.",
                    "sources": []
                }
            
            rag_chain = self.create_rag_chain()
            response = rag_chain.invoke(query)
            
            sources = []
            for doc, score in relevant_docs:
                if score < 0.7:  # similarity threshold
                    source_info = {
                        "source": doc.metadata.get("source", "Unknown"),
                        "score": float(score)
                    }
                    if source_info not in sources:
                        sources.append(source_info)
            
            return {
                "response": response,
                "sources": sources
            }
        
        except Exception as e:
            return {
                "response": f"답변 생성 중 오류가 발생했습니다: {str(e)}",
                "sources": []
            }