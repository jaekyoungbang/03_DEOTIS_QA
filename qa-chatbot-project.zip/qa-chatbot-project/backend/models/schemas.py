from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

class ChatMessage(BaseModel):
    message: str
    history: Optional[List[dict]] = []

class ChatResponse(BaseModel):
    response: str
    sources: Optional[List[str]] = []

class DocumentUpload(BaseModel):
    filename: str
    content_type: str

class DocumentInfo(BaseModel):
    id: str
    filename: str
    upload_date: datetime
    file_size: int
    status: str

class DocumentProcessResponse(BaseModel):
    success: bool
    message: str
    document_id: Optional[str] = None