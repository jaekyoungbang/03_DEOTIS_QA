import os
from typing import Optional
from pydantic_settings import BaseSettings
from dotenv import load_dotenv

load_dotenv()

class Settings(BaseSettings):
    openai_api_key: Optional[str] = None
    ollama_base_url: str = "http://127.0.0.1:11434"
    
    llm_model: str = "bnksys/yanolja-eeve-korean-instruct-10.8b:latest"
    embedding_model: str = "bge-m3:latest"
    
    chunk_size: int = 1000
    chunk_overlap: int = 200
    
    vector_db_path: str = "./chroma_db"
    
    cors_origins: list = ["*"]
    
    max_file_size: int = 50 * 1024 * 1024  # 50MB
    allowed_file_types: list = [".pdf", ".md"]
    
    class Config:
        env_file = ".env"
        case_sensitive = False

settings = Settings()