import os
import uuid
from typing import List, Optional
from PyPDF2 import PdfReader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent.parent))

from config.settings import settings

class DocumentProcessor:
    def __init__(self):
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=settings.chunk_size,
            chunk_overlap=settings.chunk_overlap,
            separators=["\n\n", "\n", ". ", "! ", "? ", "; ", ", ", " ", ""],
            length_function=len,
            is_separator_regex=False,
            keep_separator=True
        )

    def print_docs(self, documents):
        for i, doc in enumerate(documents):
            print(f"{doc.page_content}")
            print(f"-------------------------------------------------- len: {len(doc.page_content)} --------------------------------------------------")
    
    def process_pdf(self, file_path: str) -> List[Document]:
        try:
            reader = PdfReader(file_path)
            text = ""
            for page in reader.pages:
                text += page.extract_text() + "\n"
            
            documents = self.text_splitter.create_documents(
                [text],
                metadatas=[{"source": os.path.basename(file_path), "type": "pdf"}]
            )

            self.print_docs(documents)

            return documents
        except Exception as e:
            raise Exception(f"PDF 처리 중 오류 발생: {str(e)}")
    
    def process_markdown(self, file_path: str) -> List[Document]:
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                text = file.read()
            
            documents = self.text_splitter.create_documents(
                [text],
                metadatas=[{"source": os.path.basename(file_path), "type": "markdown"}]
            )
            return documents
        except Exception as e:
            raise Exception(f"마크다운 파일 처리 중 오류 발생: {str(e)}")
    
    def process_document(self, file_path: str, file_type: str) -> List[Document]:
        if file_type.lower() == ".pdf":
            return self.process_pdf(file_path)
        elif file_type.lower() == ".md":
            return self.process_markdown(file_path)
        else:
            raise Exception(f"지원하지 않는 파일 형식: {file_type}")
    
    def validate_file(self, file_path: str, file_type: str) -> bool:
        if file_type.lower() not in settings.allowed_file_types:
            return False
        
        file_size = os.path.getsize(file_path)
        if file_size > settings.max_file_size:
            return False
        
        return True