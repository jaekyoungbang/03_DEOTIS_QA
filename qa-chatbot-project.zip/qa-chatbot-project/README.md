# RAG ChatBot System

LLM RAG를 이용한 문서 기반 챗봇 시스템

## 🚀 Features

- **문서 업로드**: PDF, Markdown 파일 업로드 및 처리
- **RAG 시스템**: 문서 임베딩, 청킹, 벡터 검색
- **챗봇 인터페이스**: 실시간 질문 답변
- **관리자 기능**: 데이터베이스 관리 및 통계

## 🛠️ Tech Stack

- **Backend**: FastAPI, Python 3.11
- **LLM**: OpenAI GPT-4o-mini
- **Embedding**: OpenAI text-embedding-3-small
- **Vector DB**: ChromaDB
- **Framework**: LangChain
- **Frontend**: HTML, CSS, JavaScript

## 📁 Project Structure

```
chatbot-project/
├── backend/
│   ├── app/
│   │   └── main.py          # FastAPI 메인 애플리케이션
│   ├── config/
│   │   └── settings.py      # 환경 설정
│   ├── models/
│   │   └── schemas.py       # Pydantic 모델
│   ├── routers/
│   │   ├── chat.py         # 채팅 API
│   │   ├── documents.py    # 문서 관리 API
│   │   └── admin.py        # 관리자 API
│   ├── services/
│   │   ├── rag_service.py  # RAG 시스템
│   │   └── vector_store.py # 벡터 저장소
│   ├── utils/
│   │   └── document_processor.py # 문서 처리
│   └── requirements.txt
├── frontend/
│   ├── static/
│   │   ├── style.css       # 스타일시트
│   │   └── script.js       # JavaScript
│   └── templates/
│       └── index.html      # 메인 페이지
├── .env.example            # 환경변수 예제
└── CLAUDE.md              # 프로젝트 요구사항
```

## 🔧 Installation

1. **의존성 설치**
```bash
cd backend
pip install -r requirements.txt
```

2. **환경변수 설정**
```bash
# backend/.env 파일에 OpenAI API 키 설정
OPENAI_API_KEY=your_actual_openai_api_key
```

## 🚀 Usage

**간편 실행 (추천)**
```bash
python run.py
```

**또는 직접 실행**
```bash
cd backend
python app/main.py
```

**브라우저에서 접속**
```
http://localhost:8000
```

## 📚 API Endpoints

### Chat
- `POST /api/chat` - 챗봇과 대화
- `GET /api/health` - 채팅 서비스 상태 확인

### Documents
- `POST /api/upload` - 문서 업로드
- `GET /api/list` - 문서 목록 조회
- `DELETE /api/{document_id}` - 문서 삭제

### Admin
- `POST /api/admin/reset-database` - 데이터베이스 초기화
- `GET /api/admin/stats` - 데이터베이스 통계

## ⚙️ Configuration

`backend/config/settings.py`에서 다음 설정을 변경할 수 있습니다:

- `chunk_size`: 텍스트 청크 크기 (기본값: 1000)
- `chunk_overlap`: 청크 겹침 크기 (기본값: 200)
- `max_file_size`: 최대 파일 크기 (기본값: 50MB)
- `llm_model`: LLM 모델 (기본값: gpt-4o-mini)
- `embedding_model`: 임베딩 모델 (기본값: text-embedding-3-small)

## 🔒 Security

- API 키는 환경변수로 관리
- 파일 업로드 제한 (크기, 형식)
- CORS 설정 적용

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## 📝 License

This project is licensed under the MIT License.