class ChatBot {
    constructor() {
        this.chatMessages = document.getElementById('chat-messages');
        this.userInput = document.getElementById('user-input');
        this.sendBtn = document.getElementById('send-btn');
        this.fileInput = document.getElementById('file-input');
        this.uploadBtn = document.getElementById('upload-btn');
        this.uploadStatus = document.getElementById('upload-status');
        this.documentsList = document.getElementById('documents-list');
        this.refreshDocsBtn = document.getElementById('refresh-docs-btn');
        
        this.chatHistory = [];
        
        this.initEventListeners();
        this.loadDocuments();
    }
    
    initEventListeners() {
        this.sendBtn.addEventListener('click', () => this.sendMessage());
        this.userInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        this.uploadBtn.addEventListener('click', () => this.uploadDocument());
        this.refreshDocsBtn.addEventListener('click', () => this.loadDocuments());
    }
    
    async sendMessage() {
        const message = this.userInput.value.trim();
        if (!message) return;
        
        this.addMessage(message, 'user');
        this.userInput.value = '';
        this.sendBtn.disabled = true;
        
        this.showTypingIndicator();
        
        try {
            const response = await fetch('/api/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    message: message,
                    history: this.chatHistory
                })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            
            const data = await response.json();
            
            this.hideTypingIndicator();
            this.addMessage(data.response, 'bot', data.sources);
            
            this.chatHistory.push(
                { role: 'user', content: message },
                { role: 'assistant', content: data.response }
            );
            
            if (this.chatHistory.length > 20) {
                this.chatHistory = this.chatHistory.slice(-20);
            }
            
        } catch (error) {
            this.hideTypingIndicator();
            this.addMessage('죄송합니다. 오류가 발생했습니다. 다시 시도해주세요.', 'bot');
            console.error('Chat error:', error);
        } finally {
            this.sendBtn.disabled = false;
            this.userInput.focus();
        }
    }
    
    addMessage(content, type, sources = null) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}-message`;
        
        const contentDiv = document.createElement('div');
        contentDiv.className = 'message-content';
        
        // 마크다운을 HTML로 변환 (봇 메시지만)
        if (type === 'bot' && typeof marked !== 'undefined') {
            const htmlContent = marked.parse(content);
            contentDiv.innerHTML = htmlContent;
        } else {
            contentDiv.textContent = content;
        }
        
        messageDiv.appendChild(contentDiv);
        
        if (sources && sources.length > 0) {
            const sourcesDiv = document.createElement('div');
            sourcesDiv.className = 'message-sources';
            sourcesDiv.textContent = `출처: ${sources.map(s => s.source || s).join(', ')}`;
            messageDiv.appendChild(sourcesDiv);
        }
        
        this.chatMessages.appendChild(messageDiv);
        this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
    }
    
    showTypingIndicator() {
        const typingDiv = document.createElement('div');
        typingDiv.className = 'message bot-message typing-indicator';
        typingDiv.id = 'typing-indicator';
        
        const dotsDiv = document.createElement('div');
        dotsDiv.className = 'typing-dots';
        for (let i = 0; i < 3; i++) {
            const dot = document.createElement('div');
            dot.className = 'typing-dot';
            dotsDiv.appendChild(dot);
        }
        
        typingDiv.appendChild(dotsDiv);
        this.chatMessages.appendChild(typingDiv);
        this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
    }
    
    hideTypingIndicator() {
        const typingIndicator = document.getElementById('typing-indicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }
    
    async uploadDocument() {
        const file = this.fileInput.files[0];
        if (!file) {
            this.showUploadStatus('파일을 선택해주세요.', 'error');
            return;
        }
        
        const formData = new FormData();
        formData.append('file', file);
        
        this.uploadBtn.disabled = true;
        this.showUploadStatus('업로드 중...', 'loading');
        
        try {
            const response = await fetch('/api/upload', {
                method: 'POST',
                body: formData
            });
            
            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.detail || `HTTP ${response.status}`);
            }
            
            const data = await response.json();
            this.showUploadStatus('업로드 완료!', 'success');
            this.fileInput.value = '';
            this.loadDocuments();
            
        } catch (error) {
            this.showUploadStatus(`업로드 실패: ${error.message}`, 'error');
            console.error('Upload error:', error);
        } finally {
            this.uploadBtn.disabled = false;
        }
    }
    
    showUploadStatus(message, type) {
        this.uploadStatus.textContent = message;
        this.uploadStatus.className = `status-${type}`;
        
        if (type === 'success') {
            setTimeout(() => {
                this.uploadStatus.textContent = '';
                this.uploadStatus.className = '';
            }, 3000);
        }
    }
    
    async loadDocuments() {
        try {
            const response = await fetch('/api/list');
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            
            const documents = await response.json();
            this.displayDocuments(documents);
            
        } catch (error) {
            console.error('Load documents error:', error);
            this.documentsList.innerHTML = '<p class="no-documents">문서 목록을 불러올 수 없습니다.</p>';
        }
    }
    
    displayDocuments(documents) {
        if (!documents || documents.length === 0) {
            this.documentsList.innerHTML = '<p class="no-documents">업로드된 문서가 없습니다.</p>';
            return;
        }
        
        this.documentsList.innerHTML = '';
        
        documents.forEach(doc => {
            const docDiv = document.createElement('div');
            docDiv.className = 'document-item';
            
            const nameDiv = document.createElement('div');
            nameDiv.className = 'document-name';
            nameDiv.textContent = doc.filename;
            
            const infoDiv = document.createElement('div');
            infoDiv.className = 'document-info';
            
            const uploadDate = new Date(doc.upload_date).toLocaleDateString('ko-KR');
            const fileSize = this.formatFileSize(doc.file_size);
            
            infoDiv.innerHTML = `
                <span>업로드: ${uploadDate}</span>
                <span>크기: ${fileSize}</span>
            `;
            
            const deleteBtn = document.createElement('button');
            deleteBtn.className = 'delete-btn';
            deleteBtn.textContent = '삭제';
            deleteBtn.addEventListener('click', () => this.deleteDocument(doc.id));
            
            docDiv.appendChild(nameDiv);
            docDiv.appendChild(infoDiv);
            docDiv.appendChild(deleteBtn);
            
            this.documentsList.appendChild(docDiv);
        });
    }
    
    async deleteDocument(documentId) {
        if (!confirm('이 문서를 삭제하시겠습니까?')) {
            return;
        }
        
        try {
            const response = await fetch(`/api/${documentId}`, {
                method: 'DELETE'
            });
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            
            this.loadDocuments();
            
        } catch (error) {
            alert('문서 삭제 중 오류가 발생했습니다.');
            console.error('Delete document error:', error);
        }
    }
    
    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new ChatBot();
});