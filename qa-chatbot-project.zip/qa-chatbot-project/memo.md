● Update Todos
⎿ ☐ 프로젝트 구조 및 디렉토리 분석
☐ 데이터 플로우 및 전체 아키텍처 설명
☐ API 엔드포인트 및 라우터 구조 설명
☐ 프론트엔드와 백엔드 연동 흐름

● Update Todos
⎿ ☐ 프로젝트 구조 및 디렉토리 분석
☐ 데이터 플로우 및 전체 아키텍처 설명
☐ API 엔드포인트 및 라우터 구조 설명
☐ 프론트엔드와 백엔드 연동 흐름

● List(.)
⎿ Listed 45 paths (ctrl+r to expand)

● Read(run.py)
⎿ Read 21 lines (ctrl+r to expand)

● Read(backend/routers/documents.py)
⎿ Read 100 lines (ctrl+r to expand)

● Read(backend/routers/admin.py)
⎿ Read 32 lines (ctrl+r to expand)

● Read(frontend/static/script.js)
⎿ Read 50 lines (ctrl+r to expand)

● Read(backend/models/schemas.py)
⎿ Read 27 lines (ctrl+r to expand)

● Update Todos
⎿ ☒ 프로젝트 구조 및 디렉토리 분석
☐ 데이터 플로우 및 전체 아키텍처 설명
☐ API 엔드포인트 및 라우터 구조 설명
☐ 프론트엔드와 백엔드 연동 흐름

● RAG 챗봇 프로젝트 전반적인 흐름

📁 프로젝트 구조

chatbot-project/
├── 🚀 run.py # 메인 실행 파일
├── backend/ # 백엔드 (FastAPI)
│ ├── app/main.py # FastAPI 애플리케이션 진입점
│ ├── config/settings.py # 설정 관리
│ ├── models/schemas.py # 데이터 모델 정의
│ ├── routers/ # API 라우터
│ │ ├── chat.py # 챗봇 대화 API
│ │ ├── documents.py # 문서 관리 API
│ │ └── admin.py # 관리자 기능 API
│ ├── services/ # 핵심 비즈니스 로직
│ │ ├── rag_service.py # RAG 시스템 핵심
│ │ └── vector_store.py # 벡터 데이터베이스 관리
│ ├── utils/ # 유틸리티 함수
│ │ └── document_processor.py # 문서 처리
│ ├── uploads/ # 업로드된 파일 저장
│ └── chroma_db/ # ChromaDB 벡터 저장소
└── frontend/ # 프론트엔드 (HTML/JS/CSS)
├── static/
└── templates/

🔄 전체 시스템 아키텍처 & 데이터 플로우

1. 문서 업로드 및 처리 흐름

graph TD
A[사용자 파일 업로드] --> B[documents.py: /upload]
B --> C[DocumentProcessor: 파일 검증]
C --> D[텍스트 추출 PDF/MD]
D --> E[RecursiveCharacterTextSplitter: 청킹]
E --> F[OpenAI Embeddings: 벡터화]
F --> G[ChromaDB: 벡터 저장]
G --> H[메타데이터 저장]

2. 질의 응답 (RAG) 흐름

graph TD
A[사용자 질문] --> B[chat.py: /chat]
B --> C[RAGService: 질의 처리]
C --> D[VectorStore: enhanced_similarity_search]
D --> E[질의 전처리 & 키워드 추출]
E --> F[벡터 유사도 검색]
F --> G[다중 메트릭 재랭킹]
G --> H[관련 문서 추출]
H --> I[LangChain RAG 체인]
I --> J[OpenAI GPT: 답변 생성]
J --> K[구조화된 응답 반환]

🌐 API 엔드포인트 구조

● Update Todos
⎿ ☒ 프로젝트 구조 및 디렉토리 분석
☒ 데이터 플로우 및 전체 아키텍처 설명
☐ API 엔드포인트 및 라우터 구조 설명
☐ 프론트엔드와 백엔드 연동 흐름

● 🔗 Chat Router (/api)

- POST /chat - 사용자 질문에 대한 RAG 기반 답변
- GET /health - 챗봇 서비스 상태 확인

📄 Documents Router (/api)

- POST /upload - 문서 업로드 및 벡터화
- GET /list - 업로드된 문서 목록 조회
- DELETE /{document_id} - 특정 문서 삭제

⚙️ Admin Router (/api/admin)

- POST /reset-database - 벡터 데이터베이스 초기화
- GET /stats - 데이터베이스 통계 정보

🖥️ Static Routes

- GET / - 메인 웹 인터페이스
- /static/\* - CSS, JS 정적 파일

🎨 프론트엔드 ↔ 백엔드 연동

● Update Todos
⎿ ☒ 프로젝트 구조 및 디렉토리 분석
☒ 데이터 플로우 및 전체 아키텍처 설명
☒ API 엔드포인트 및 라우터 구조 설명
☐ 프론트엔드와 백엔드 연동 흐름

● 📱 Frontend (script.js)

- ChatBot 클래스: 전체 UI 관리
- sendMessage(): /api/chat으로 질문 전송
- uploadDocument(): /api/upload으로 파일 업로드
- loadDocuments(): /api/list에서 문서 목록 로드

🔄 실시간 상호작용

1. 채팅: 사용자 입력 → API 호출 → 응답 표시
2. 파일 업로드: 드래그&드롭 → 진행률 표시 → 성공/실패 알림
3. 문서 관리: 실시간 목록 갱신 및 삭제

⚡ 핵심 기술 스택

백엔드

- FastAPI: 고성능 비동기 웹 프레임워크
- LangChain: RAG 파이프라인 구축
- OpenAI: 임베딩 & LLM (text-embedding-3-small, GPT-4)
- ChromaDB: 벡터 데이터베이스
- PyPDF2: PDF 텍스트 추출

프론트엔드

- Vanilla JavaScript: 심플한 SPA
- Fetch API: 비동기 통신
- CSS Grid/Flexbox: 반응형 레이아웃

🎯 주요 특징

1. 향상된 검색 정확도: 다중 메트릭 재랭킹 시스템
2. 의미적 청킹: 구두점 기반 스마트 분할 (300자 단위)
3. 실시간 로깅: 전 과정 추적 가능
4. 사용자 친화적 인터페이스: 직관적인 채팅 & 파일 관리
5. 형식적 응답: 정중하고 구조화된 답변 생성

● Update Todos
⎿ ☒ 프로젝트 구조 및 디렉토리 분석
☒ 데이터 플로우 및 전체 아키텍처 설명
☒ API 엔드포인트 및 라우터 구조 설명
☒ 프론트엔드와 백엔드 연동 흐름

● 🚀 실행 흐름

1. 시작: python run.py → FastAPI 서버 구동
2. 문서 업로드: PDF/MD 파일 → 청킹 → 벡터화 → ChromaDB 저장
3. 질의 응답: 질문 입력 → 유사도 검색 → 재랭킹 → GPT 답변 생성
4. 관리: 문서 목록 확인, 삭제, DB 초기화

이 프로젝트는 엔터프라이즈급 RAG 시스템으로, 문서 기반 질의응답에 최적화된 완전한 풀스택 솔루션입니다.
