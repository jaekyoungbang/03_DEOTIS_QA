#!/usr/bin/env python3

import sys
import os
from pathlib import Path

project_root = Path(__file__).parent
backend_path = project_root / "backend"

sys.path.insert(0, str(backend_path))

os.chdir(backend_path)

if __name__ == "__main__":
    import uvicorn
    
    print("🚀 RAG ChatBot 서버를 시작합니다...")
    print("📝 http://localhost:8000 에서 확인하세요")
    print("💡 .env 파일에 OPENAI_API_KEY를 설정해주세요")
    
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)